# @hellave/js-sdk

Browser-first, framework-agnostic ESM SDK for participating in Hellave rooms.

The package is pre-1.0 while the Production Core contract is completed. It attaches
through one Public Edge, returns a server-authoritative `Conference`, exposes
capability-checked lobby decisions, and publishes real microphone media through stable
domain objects while WebRTC and media credentials stay internal to the SDK. See the
[repository index](https://github.com/agenpocomp/Hellave-SDKS) for immutable internal
installation and release verification. Backend setup and the complete callable API are
in the separate
[integration guide](https://github.com/agenpocomp/Hellave-SDKS/blob/main/docs/integration-guide.md).
